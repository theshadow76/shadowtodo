import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:shadowtodo/body.dart';
import 'package:shadowtodo/screens/login/login.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io' show Platform;
import 'package:purchases_flutter/purchases_flutter.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

final emailController = TextEditingController();
final passwordController = TextEditingController();
String errorText = '';

class _RegisterState extends State<Register> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 92, 197, 252),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Center(
                child: Text(
              "ShadowTodo",
              style: TextStyle(fontSize: 45, color: Colors.white),
            )),
          ),
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Center(
                child: Text(
              "Hello. Register here!",
              style: TextStyle(fontSize: 45, color: Colors.white),
            )),
          ),
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Column(
              children: [
                Text(
                  "Email",
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(top: 10),
                    width: MediaQuery.of(context).size.width - 20,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(12.0))),
                    child: TextField(
                      textAlign: TextAlign.center,
                      controller: emailController,
                      decoration: InputDecoration(
                        hintText: "Email here",
                      ),
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top: 25),
                    child: Text(
                      "Password",
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    )),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(top: 10),
                    width: MediaQuery.of(context).size.width - 20,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(12.0))),
                    child: TextField(
                      textAlign: TextAlign.center,
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        hintText: "Password here",
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 30),
                    width: MediaQuery.of(context).size.width - 20,
                    height: 40,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(12.0)),
                        color: Colors.grey[900]),
                    child: Center(
                        child: Text(
                      "Register",
                      style: TextStyle(color: Colors.white),
                    )),
                  ),
                  onTap: signUp
                ),
                Text(errorText, style: TextStyle(color: Colors.red),),
                Container(
                  margin: EdgeInsets.only(top: 60),
                  width: MediaQuery.of(context).size.width - 20,
                  height: 1,
                  color: Colors.white,
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 50),
                    width: MediaQuery.of(context).size.width - 20,
                    height: 40,
                    color: Colors.white,
                    child: Center(child: Text("Folow us on instagram")),
                  ),
                  onTap: (() {
                    launch(
                        "https://www.instagram.com/tienda_shadowtech_software/");
                  }),
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 40),
                    child: Text("Already have a accoun? Login here"),
                  ),
                  onTap: (() {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (BuildContext context) => Login()));
                  }),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Future signUp() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: emailController.text.trim(),
              password: passwordController.text.trim());
      Navigator.push(context,
          MaterialPageRoute(builder: (BuildContext context) => HomePage()));
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        //errorText = "The password provided is to weak";
        setState(() {
          errorText = "The password provided is to weak";
        });
      } else if (e.code == 'email-already-in-use') {
        //errorText = "The account already exists for that email";
        setState(() {
          errorText = "The account already exists";
        });
      } else if (passwordController.text.trim() == "") {
        setState(() {
          errorText = "please enter a password!";
        });
      }
    }
  }
}
