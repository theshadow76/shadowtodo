import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:shadowtodo/body.dart';
import 'package:shadowtodo/screens/register/register.dart';
import 'package:url_launcher/url_launcher.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _RegisterState();
}

String errorText = "";
final emailController = TextEditingController();
final passwordController = TextEditingController();
class _RegisterState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 92, 197, 252),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Center(
                child: Text(
              "ShadowTodo",
              style: TextStyle(fontSize: 45, color: Colors.white),
            )),
          ),
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Center(
                child: Text(
              "Hello. Login here!",
              style: TextStyle(fontSize: 45, color: Colors.white),
            )),
          ),
          Container(
            margin: EdgeInsets.only(top: 30),
            child: Column(
              children: [
                Text(
                  "Email",
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(top: 10),
                    width: MediaQuery.of(context).size.width - 20,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(12.0))),
                    child: TextField(
                      textAlign: TextAlign.center,
                      controller: emailController,
                      decoration: InputDecoration(
                        hintText: "Email here",
                      ),
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top: 25),
                    child: Text(
                      "Password",
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    )),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(top: 10),
                    width: MediaQuery.of(context).size.width - 20,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(12.0))),
                    child: TextField(
                      textAlign: TextAlign.center,
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        hintText: "Password here",
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 30),
                    width: MediaQuery.of(context).size.width - 20,
                    height: 40,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(12.0)),
                        color: Colors.grey[900]),
                    child: Center(
                        child: Text(
                      "Login",
                      style: TextStyle(color: Colors.white),
                    )),
                  ),
                  onTap: signIn,
                ),
                Container(
                  margin: EdgeInsets.only(top: 60),
                  width: MediaQuery.of(context).size.width - 20,
                  height: 1,
                  color: Colors.white,
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 50),
                    width: MediaQuery.of(context).size.width - 20,
                    height: 40,
                    color: Colors.white,
                    child: Center(child: Text("Folow us on instagram")),
                  ),
                  onTap: (() {
                    launch("https://www.instagram.com/tienda_shadowtech_software/");
                  }),
                ),
                GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 40),
                    child: Text("Don't have a accoun? Register here"),
                  ),
                  onTap: (() {
                    Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) => Register()));
                  }),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Future signIn() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
              email: emailController.text.trim(),
              password: passwordController.text.trim());
      Navigator.push(context,
          MaterialPageRoute(builder: (BuildContext context) => HomePage()));
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        setState(() {
          errorText = "User not found";
        });
      } else if (e.code == 'wrong-password') {
        setState(() {
          errorText = "Incorrect password";
        });
      }
      else if (passwordController.text.trim() == "") {
        setState(() {
          errorText = "please enter a password!";
        });
      }
    }
  }

}