import 'package:admob_flutter/admob_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:shadowtodo/ad_state.dart';
import 'package:shadowtodo/screens/register/register.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'ad_helper.dart';
import 'firebase_options.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

var FireCurentUser = FirebaseAuth.instance.currentUser;
TimeOfDay selectedTime = TimeOfDay.now();
final Stream<QuerySnapshot> _usersStream = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Monday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamtue = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Tuesday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamwed = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Wednesday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamthu = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Thursday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamfri = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Friday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamsat = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Saturday")
    .snapshots();

final Stream<QuerySnapshot> _usersStreamsun = FirebaseFirestore.instance
    .collection('Tasks')
    .doc("data ${FireCurentUser?.email}")
    .collection("Day Sunday")
    .snapshots();

class _HomePageState extends State<HomePage> {
  // variables
  String datenowmonth = DateTime.now().month.toString();
  String datenowday = DateTime.now().day.toString();
  String datenowyear = DateTime.now().year.toString();
  DateTime today = DateTime.now();
  double varDay = DateTime.now().day.toDouble();
  var MonColor = Colors.grey;
  var TueColor = Colors.grey;
  var WedColor = Colors.grey;
  var ThuColor = Colors.grey;
  var FriColor = Colors.grey;
  var SatColor = Colors.grey;
  var SunColor = Colors.grey;
  String NotasksforMon = "";
  String NotasksforTue = "";
  String NotasksforWed = "";
  String NotasksforThu = "";
  String NotasksforFri = "";
  String NotasksforSat = "";
  String NotasksforSun = "";
  String noTask = "";
  String WhichDayisit = "";
  var ispresedtochangecolor = Colors.transparent;
  var MonColor2 = Colors.grey;
  var TueColor2 = Colors.grey;
  var WedColor2 = Colors.grey;
  var ThuColor2 = Colors.grey;
  var FriColor2 = Colors.grey;
  var SatColor2 = Colors.grey;
  var SunColor2 = Colors.grey;
  bool isthetaskgoodtoappear = false;
  String TaskTitle = "";
  String taskDescription = "";
  String VARdayToBe = "";
  List Items = [];
  List<String> Itemstue = [];
  List<String> Itemswed = [];
  List<String> Itemsthu = [];
  List<String> Itemsfri = [];
  List<String> Itemssat = [];
  List<String> Itemssun = [];
  bool apearinmon = false;
  bool apearintue = false;
  bool apearinwed = false;
  bool apearinthu = false;
  bool apearinfri = false;
  bool apearinsat = false;
  bool apearinsun = false;
  var wichDayIsItForReadData = "";
  List DoDateTask = [];
  List TaskDataDescription = [];
  List DoDateTasktue = [];
  List TaskDataDescriptiontue = [];
  List DoDateTaskwed = [];
  List TaskDataDescriptionwed = [];
  List DoDateTaskthu = [];
  List TaskDataDescriptionthu = [];
  List DoDateTaskfri = [];
  List TaskDataDescriptionfri = [];
  List DoDateTasksat = [];
  List TaskDataDescriptionsat = [];
  List DoDateTasksun = [];
  List TaskDataDescriptionsun = [];
  var TaskHourData = "";
  bool IsVisible = true;
  bool _isBannerAdReady = false;
  late AdmobInterstitial interstitial;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    
    WidgetsFlutterBinding.ensureInitialized();

    Future FlutterAuthOne() async {
      // it detects if the user is not signed in.
      FirebaseAuth.instance.authStateChanges().listen((User? user) {
        if (user == null) {
          Navigator.push(context,
              MaterialPageRoute(builder: (BuildContext context) => Register()));
        }
      });
    }

    // iniciar las funciones
    FlutterAuthOne();
    readDataFromFirebase();
    logic();

    print(FireCurentUser?.email);
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/background.png"), fit: BoxFit.cover)),
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          child: Icon(
            Icons.add,
            color: Colors.white,
            size: 40,
          ),
          onPressed: (() {
            showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text("Add Todo"),
                    content: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 20),
                          width: MediaQuery.of(context).size.width - 20,
                          color: Colors.white,
                          child: TextField(
                            onChanged: ((value) => {
                                  setState(() {
                                    TaskTitle = value;
                                  })
                                }),
                            decoration: InputDecoration(
                                hintText: "Add the title of the task"),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 20),
                          width: MediaQuery.of(context).size.width - 20,
                          color: Colors.white,
                          child: TextField(
                            onChanged: ((value) => {
                                  setState(() {
                                    taskDescription = value;
                                  })
                                }),
                            decoration: InputDecoration(
                                hintText: "Add the description of the task"),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          child: Text(
                              "Please select a day where the task is do for."),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 25),
                          child: Row(
                            children: [
                              GestureDetector(
                                child: Container(
                                    color: MonColor2, child: Text("Monday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Monday";
                                    ispresedtochangecolor = Colors.transparent;
                                    MonColor2 = Colors.blue;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                              Spacer(),
                              GestureDetector(
                                child: Container(
                                    color: TueColor2, child: Text("Tuesday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Tuesday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.blue;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                              Spacer(),
                              GestureDetector(
                                child: Container(
                                    color: WedColor2, child: Text("Wednesday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Wednesday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.blue;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                              Spacer(),
                              GestureDetector(
                                child: Container(
                                    color: ThuColor2, child: Text("Thursday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Thursday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.blue;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: Row(
                            children: [
                              GestureDetector(
                                child: Container(
                                    color: FriColor2, child: Text("Friday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Friday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.blue;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                              Spacer(),
                              GestureDetector(
                                child: Container(
                                    color: SatColor2, child: Text("Saturday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Saturday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.blue;
                                    SunColor2 = Colors.grey;
                                  });
                                }),
                              ),
                              Spacer(),
                              GestureDetector(
                                child: Container(
                                    color: SunColor2, child: Text("Sunday")),
                                onTap: (() {
                                  setState(() {
                                    WhichDayisit = "Sunday";
                                    MonColor2 = Colors.grey;
                                    TueColor2 = Colors.grey;
                                    WedColor2 = Colors.grey;
                                    ThuColor2 = Colors.grey;
                                    FriColor2 = Colors.grey;
                                    SatColor2 = Colors.grey;
                                    SunColor2 = Colors.blue;
                                  });
                                }),
                              ),
                            ],
                          ),
                        ),
                        FlatButton(
                          child: Container(child: Text("Create Task")),
                          onPressed: timepicker,
                        ),
                        FlatButton(
                          child: Container(child: Text("Cancel")),
                          onPressed: (() {
                            Navigator.of(context, rootNavigator: true)
                                .pop('dialog');
                          }),
                        )
                      ],
                    ),
                  );
                });
          }),
        ),
        body: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 50.0),
              child: Center(
                child: Text(
                  "ShadowTodo",
                  style: TextStyle(color: Colors.black, fontSize: 45),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 50, right: 50, top: 30),
              child: Row(
                children: [
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Mon",
                      style: TextStyle(color: MonColor),
                    )),
                    onTap: (() => {
                          MonTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Monday";
                            MonColor = Colors.blue;
                            TueColor = Colors.grey;
                            WedColor = Colors.grey;
                            ThuColor = Colors.grey;
                            FriColor = Colors.grey;
                            SatColor = Colors.grey;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Tue",
                      style: TextStyle(color: TueColor),
                    )),
                    onTap: (() => {
                          TueTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Tuesday";
                            MonColor = Colors.grey;
                            TueColor = Colors.blue;
                            WedColor = Colors.grey;
                            ThuColor = Colors.grey;
                            FriColor = Colors.grey;
                            SatColor = Colors.grey;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Wed",
                      style: TextStyle(color: WedColor),
                    )),
                    onTap: (() => {
                          WedTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Wednesday";
                            MonColor = Colors.grey;
                            TueColor = Colors.grey;
                            WedColor = Colors.blue;
                            ThuColor = Colors.grey;
                            FriColor = Colors.grey;
                            SatColor = Colors.grey;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Thu",
                      style: TextStyle(color: ThuColor),
                    )),
                    onTap: (() => {
                          ThuTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Thursday";
                            MonColor = Colors.grey;
                            TueColor = Colors.grey;
                            WedColor = Colors.grey;
                            ThuColor = Colors.blue;
                            FriColor = Colors.grey;
                            SatColor = Colors.grey;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Fri",
                      style: TextStyle(color: FriColor),
                    )),
                    onTap: (() => {
                          FriTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Friday";
                            MonColor = Colors.grey;
                            TueColor = Colors.grey;
                            WedColor = Colors.grey;
                            ThuColor = Colors.grey;
                            FriColor = Colors.blue;
                            SatColor = Colors.grey;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Sat",
                      style: TextStyle(color: SatColor),
                    )),
                    onTap: (() => {
                          SatTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Saturday";
                            MonColor = Colors.grey;
                            TueColor = Colors.grey;
                            WedColor = Colors.grey;
                            ThuColor = Colors.grey;
                            FriColor = Colors.grey;
                            SatColor = Colors.blue;
                            SunColor = Colors.grey;
                          })
                        }),
                  ),
                  Spacer(),
                  GestureDetector(
                    child: Container(
                        child: Text(
                      "Sun",
                      style: TextStyle(color: SunColor),
                    )),
                    onTap: (() => {
                          SunTasks(),
                          setState(() {
                            wichDayIsItForReadData = "Sunday";
                            MonColor = Colors.grey;
                            TueColor = Colors.grey;
                            WedColor = Colors.grey;
                            ThuColor = Colors.grey;
                            FriColor = Colors.grey;
                            SatColor = Colors.grey;
                            SunColor = Colors.blue;
                          })
                        }),
                  ),
                  if (wichDayIsItForReadData == "Monday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStream,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Items.add(data['Task Title']);
                              DoDateTask.add(data['Hour']);
                              TaskDataDescription.add(data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Tuesday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamtue,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemstue.add(data['Task Title']);
                              DoDateTasktue.add(data['day']);
                              TaskDataDescriptiontue.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Wednesday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamwed,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemswed.add(data['Task Title']);
                              DoDateTaskwed.add(data['Hour']);
                              TaskDataDescriptionwed.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Thursday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamthu,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemsthu.add(data['Task Title']);
                              DoDateTaskthu.add(data['Hour']);
                              TaskDataDescriptionthu.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Friday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamfri,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemsfri.add(data['Task Title']);
                              DoDateTaskfri.add(data['Hour']);
                              TaskDataDescriptionfri.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Saturday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamsat,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemssat.add(data['Task Title']);
                              DoDateTasksat.add(data['Hour']);
                              TaskDataDescriptionsat.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                  if (wichDayIsItForReadData == "Sunday") ...[
                    Container(
                      margin: EdgeInsets.only(top: 70),
                      child: StreamBuilder<QuerySnapshot>(
                        stream: _usersStreamsun,
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return Text('Something went wrong');
                          }

                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Text("");
                          }
                          return ListView(
                            shrinkWrap: true,
                            children: snapshot.data!.docs
                                .map((DocumentSnapshot document) {
                              Map<String, dynamic> data =
                                  document.data()! as Map<String, dynamic>;
                              print(data);
                              Itemssun.add(data['Task Title']);
                              DoDateTasksun.add(data['Hour']);
                              TaskDataDescriptionsun.add(
                                  data['TaskDescriptiom']);
                              return Container();
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (wichDayIsItForReadData == "Monday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Visibility(
                      child: Expanded(
                        // here is the tasks creator from firebase
                        child: SingleChildScrollView(
                          child: Container(
                              child: ListView(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            children: Items.toSet().map((strone) {
                              //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                              return Row(
                                children: [
                                  Container(
                                      child: Text(strone),
                                      margin: EdgeInsets.all(5),
                                      padding: EdgeInsets.all(15),
                                      decoration: BoxDecoration(
                                          color: Color.fromARGB(
                                              255, 11, 146, 199))),
                                ],
                              );
                            }).toList(),
                          )),
                        ),
                      ),
                    ),
                    Visibility(
                      child: Expanded(
                        // here is the tasks creator from firebase
                        child: SingleChildScrollView(
                          child: Container(
                              child: ListView(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            children: TaskDataDescription.toSet().map((strone) {
                              //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                              return Row(
                                children: [
                                  Container(
                                      child: Text(strone),
                                      margin: EdgeInsets.all(5),
                                      padding: EdgeInsets.all(15),
                                      decoration: BoxDecoration(
                                          color: Color.fromARGB(
                                              255, 11, 146, 199))),
                                ],
                              );
                            }).toList(),
                          )),
                        ),
                      ),
                    ),
                    Visibility(
                      child: Expanded(
                        // here is the tasks creator from firebase
                        child: SingleChildScrollView(
                          child: Container(
                              child: ListView(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            children: DoDateTask.toSet().map((strone) {
                              //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                              return Row(
                                children: [
                                  Container(
                                      child: Text(strone),
                                      margin: EdgeInsets.all(5),
                                      padding: EdgeInsets.all(15),
                                      decoration: BoxDecoration(
                                          color: Color.fromARGB(
                                              255, 11, 146, 199))),
                                ],
                              );
                            }).toList(),
                          )),
                        ),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Tuesday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemstue.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptiontue.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTasktue.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Wednesday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemswed.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptionwed.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTaskwed.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Thursday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemsthu.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptionthu.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTaskthu.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Friday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemsfri.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptionfri.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTaskfri.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Saturday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemssat.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptionsat.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTasksat.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
            if (wichDayIsItForReadData == "Sunday") ...[
              Container(
                width: MediaQuery.of(context).size.width - 20,
                color: Color.fromARGB(255, 11, 146, 199),
                child: Row(
                  children: [
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: Itemssun.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children:
                              TaskDataDescriptionsun.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                    Expanded(
                      // here is the tasks creator from firebase
                      child: SingleChildScrollView(
                        child: Container(
                            child: ListView(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          children: DoDateTasksun.toSet().map((strone) {
                            //Basicamente este codigo printea en pantalla cada item de la lista Items automaticamente
                            return Container(
                                child: Text(strone),
                                margin: EdgeInsets.all(5),
                                padding: EdgeInsets.all(15),
                                decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 11, 146, 199)));
                          }).toList(),
                        )),
                      ),
                    ),
                  ],
                ),
              ), // is the graphical interface
            ],
          ],
        ),
        persistentFooterButtons: [
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 50),
                child: Icon(
                  Icons.home_rounded,
                  color: Colors.blue,
                ),
              ),
              Spacer(),
              GestureDetector(
                child: Container(
                  margin: EdgeInsets.only(right: 50),
                  child: Icon(Icons.account_box_rounded),
                ),
                onTap: (() {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text("Log out?"),
                          content: GestureDetector(
                            child: Text("press here to log out!"),
                            onTap: (() {
                              FirebaseAuth.instance.signOut();
                            }),
                          ),
                        );
                      });
                }),
              )
            ],
          )
        ],
      ),
    );
  }

  logic() {
    if (wichDayIsItForReadData == "Monday") {
      setState(() {
        VARdayToBe = "Monday";
        apearinmon = true;
      });
    } else if (wichDayIsItForReadData == "Tuesday") {
      setState(() {
        VARdayToBe = "Tuesday";
        apearintue = true;
      });
    } else if (wichDayIsItForReadData == "Wednesday") {
      setState(() {
        VARdayToBe = "Wednesday";
        apearinwed = true;
      });
    } else if (wichDayIsItForReadData == "Thursday") {
      setState(() {
        VARdayToBe = "Thursday";
        apearinthu = true;
      });
    } else if (wichDayIsItForReadData == "Friday") {
      setState(() {
        VARdayToBe = "Friday";
        apearinfri = true;
      });
    } else if (wichDayIsItForReadData == "Saturday") {
      setState(() {
        VARdayToBe = "Saturday";
        apearinsat = true;
      });
    } else if (wichDayIsItForReadData == "Sunday") {
      setState(() {
        VARdayToBe = "Sunday";
        apearinsun = true;
      });
    }
  }

  // funciones
  timepicker() {
    Navigator.of(context, rootNavigator: true).pop('dialog');

    showTimePicker(
            context: context,
            initialTime: selectedTime,
            initialEntryMode: TimePickerEntryMode.dial,
            confirmText: "CONFIRM",
            cancelText: "NOT NOW",
            helpText: "BOOKING TIME")
        .then((value) => {
              setState(() {
                TaskHourData = value.toString();
              })
            });
    FirebaseFirestore.instance
        .collection("Tasks")
        .doc("data ${FireCurentUser?.email}")
        .collection("Day ${WhichDayisit}")
        .doc("datases $TaskTitle")
        .set({
      "Task Title": TaskTitle,
      "TaskDescriptiom": taskDescription,
      "day": WhichDayisit,
      "Hour": TaskHourData
    });
  }

  readDataFromFirebase() {
    StreamBuilder<QuerySnapshot>(
      stream: _usersStream,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Something went wrong');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Text("Loading");
        }

        return ListView(
          children: snapshot.data!.docs.map((DocumentSnapshot document) {
            Map<String, dynamic> data =
                document.data()! as Map<String, dynamic>;
            return ListTile(
              title: Text(data['datases']),
            );
          }).toList(),
        );
      },
    );
  }

  MonTasks() {
    setState(() {
      NotasksforMon = "looks like a free day!";
      noTask = "looks like a free Monday!";
    });
  }

  TueTasks() {
    setState(() {
      NotasksforTue = "looks like a free day!";
      noTask = "looks like a free Tuesday!";
    });
  }

  WedTasks() {
    setState(() {
      NotasksforWed = "looks like a free day!";
      noTask = "looks like a free Wednesday!";
    });
  }

  ThuTasks() {
    setState(() {
      NotasksforThu = "looks like a free day!";
      noTask = "looks like a free Thuirsday!";
    });
  }

  FriTasks() {
    setState(() {
      NotasksforFri = "looks like a free day!";
      noTask = "looks like a free Friday!";
    });
  }

  SatTasks() {
    setState(() {
      NotasksforSat = "looks like a free day!";
      noTask = "looks like a free Saterday!";
    });
  }

  SunTasks() {
    setState(() {
      NotasksforSun = "looks like a free day!";
      noTask = "looks like a free Sunday!";
    });
  }

  waitTodeleteTheData() async {
    await Future.delayed(Duration(days: 1), () {
      FirebaseFirestore.instance
          .collection("Tasks")
          .doc("data ${FireCurentUser?.email}").delete();
    });
  }
}
