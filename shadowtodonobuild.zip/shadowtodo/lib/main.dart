import 'package:admob_flutter/admob_flutter.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:shadowtodo/ad_state.dart';
import 'package:shadowtodo/body.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'dart:io' show Platform;
import 'package:purchases_flutter/purchases_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Admob.initialize();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MyApp());
}

Future<void> initPlatformState() async {
  await Purchases.setDebugLogsEnabled(true);

  if (Platform.isAndroid) {
    await Purchases.setup(
        "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiX1iOYWAlcfohr1hTqXYcO2l+7Pu7Ze2SlM6/Eqikf3UYvtA/IW6qQEhxd/lbBAH9/VTtT6Hczx0cgEPqWm5mrGPPFU4L48dhGo1pffKeMRALlLG/W3dI8/ENHjKLSqSCN4x8ZTwIQRdtV37zHrY7gn2rc1j3e0d5p8yXSuzSkw97cvxO8SIDtUde6YAkXSnvL691lIOX+zXjot/kslu1o48i1FjVljhhYt6Z4piWA8O71mq9LzJDeoxiA565vG10+2PyXpMoHPMESU8opC8Gm1fMlohtczXlp/N7Pso9PoOJ/MiCVVeWnrO3nPkHKq6t+s1BV95dYsNux5VJ652awIDAQAB");
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(scaffoldBackgroundColor: Colors.white),
      home: HomePage(),
    );
  }
}
